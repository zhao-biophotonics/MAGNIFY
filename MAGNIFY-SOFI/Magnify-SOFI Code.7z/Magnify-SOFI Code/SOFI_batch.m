%Magnify-SOFI batch processing code for 3D SOFI with deconvolution 
%and intensity correction. 
%
%Expected output: for each SOFI image, a folder will be created containing
%tif files with 2ed and 3rd order SOFI images. 
%

%Data is expected to be in .nd2 format, with all data from a single image
%contained in a folder. Each .nd2 file is expected to be a single time
%series for a single channel in a single z plane. 
%
%Batch processing assumes multiple FOVs are stored in separate subfolders
%for a single image. 
%
%Based off of cryoSOFI_3D from https://github.com/rainerkaufmann/cryoSOFI
%Updated 2023 Jan, Aleksandra Klimas.

clc;clear;close all;warning off;
%%


batchmode=true; %Batch process?
channelnumber=1; %number of color channels
driftCorrection = true; %Drift correction?

%Load data
path_name='';
mapName='abc.nd2';
path_name = uigetdir(path_name);
everything = dir(path_name);
subfolders = everything([everything.isdir]);
subfolders = subfolders(3:end);

%To generate 3D PSF for the first deconvolution
mag = 1;
magz = 1;
params.size = [7*mag 7*mag 1*magz];
params.numBasis = 100;
params.numSamp = 1000;
params.NA = 1.2;
params.M = 90;
params.ni0 = 1.33;
params.resLateral = 74e-9/mag;
params.resAxial = 300e-9/magz;
params.pZ = 0;
tic;
PSF = MicroscPSF(params);

t = toc;


%%
%To generate 3D PSF for the second deconvolution
mag2 = 2;
magz2 = 2;
params.size = [7*mag2 7*mag2 1];
params.numBasis = 100;
params.numSamp = 1000;
params.NA = 1.2;
params.M = 90;
params.ni0 = 1.33;
params.resLateral = 74e-9/mag2;
params.resAxial = 300e-9/magz2;
params.pZ = 0;
tic;
PSF2 = MicroscPSF(params);
PSF2 = PSF2.^2;
t = toc;
%%

mag3 = 3;
magz3 = 3;
params.size = [7*mag3 7*mag3 1];
params.numBasis = 100;
params.numSamp = 1000;
params.NA = 1.2;
params.M = 90;
params.ni0 = 1.33;
params.resLateral = 74e-9/mag3;
params.resAxial = 300e-9/magz3;
params.pZ = 0;
tic;
PSF3 = MicroscPSF(params);
PSF3 = PSF3.^3;
%%



tic
%%
for g=1:length(subfolders)
path_name = [subfolders(g).folder, '\', subfolders(g).name]

for colorseq=1:channelnumber
    if batchmode
        clear data_rs2
        fprintf('Loading data...\n\n')
        rector = dir([path_name,'\*.nd2']);
        for h=1+(colorseq-1)*length(rector)/channelnumber:length(rector)/channelnumber*colorseq

            mapName = rector(h).name;
            nd = bfopen([rector(h).folder '\' rector(h).name]);
            for tt = 1:length(nd{1,1})
                data_rs2(:,:,h-(colorseq-1)*length(rector)/channelnumber,tt)  = nd{1,1}{tt,1};
            end

        end
        [sx,sy,sz,st]=size(data_rs2);
    else
        data = imread_big([path_name,mapName]);
        [sx,sy,s]=size(data);
        data_re = reshape(data,sx,sy,50,[]);
        [~,~,st,sz]=size(data_re);

        for i=1:sz
            data_rs2(:,:,i,:)=data_re(:,:,:,i); %swap the dimensions of the matrix.
        end
    end
    toc
    data_rs2 = data_rs2 - 100;
    data_rs2 = uint16(rescale(data_rs2,0, 61000));

    %%
    %Drifting correction
    tic
    fprintf('Drifting correction...\n');
    if driftCorrection
        for j=1:sz
            if j>1

                [data_rs2(:,:,j,1),~,~]=driftCorr(data_rs2(:,:,j-1,1),data_rs2(:,:,j,1));

            end
            for i=2:st

                [data_rs2(:,:,j,i),~,~]=driftCorr(data_rs2(:,:,j,1),data_rs2(:,:,j,i));

            end

        end
    end
    toc
    %%
    %Intensity correction
    fprintf('Intensity correction...\n');
    mean_data_rs2=mean(data_rs2,[1 2]);
    data_rs2=uint16(single(data_rs2).*(mean(single(data_rs2),'all')./single(mean_data_rs2)));

    %%
    tic
    output=ACXC3DSOFI(data_rs2,'quick');
    %%
    fprintf('Saving images\n\n')
    saveastiff(uint16(mean(data_rs2,4)),[path_name,'\v4-' num2str(colorseq) '\original_' mapName(1:end-7) '.tif' ]);
    saveastiff(uint16(output.AC2/max(output.AC2,[],'all')*60000),[path_name,'\v4-' num2str(colorseq) '\3DACSOFI-2ndOrder-driftcorr_' mapName(1:end-7) '.tif' ]);
    saveastiff(uint16(output.AC3/max(output.AC3,[],'all')*60000),[path_name,'\v4-' num2str(colorseq) '\3DACSOFI-3rdOrder-driftcorr_' mapName(1:end-7) '.tif' ]);


    saveastiff(uint16(output.XC2/max(output.XC2,[],'all')*60000),[path_name,'\v4-' num2str(colorseq) '\3DXCSOFI-2ndOrder-driftcorr_' mapName(1:end-7) '.tif' ]);
    saveastiff(uint16(output.XC3/max(output.XC3,[],'all')*60000),[path_name,'\v4-' num2str(colorseq) '\3DXCSOFI-3rdOrder-driftcorr_' mapName(1:end-7) '.tif' ]);
    saveastiff(uint16(output.XC2.^0.5/max(output.XC2,[],'all')^0.5*60000),[path_name,'\v4-' num2str(colorseq) '\3DXCSOFI-2ndOrder-driftcorr_Icorr' mapName(1:end-7) '.tif' ]);
    saveastiff(uint16(output.XC3.^0.33/max(output.XC3,[],'all')^0.33*60000),[path_name,'\v4-' num2str(colorseq) '\3DXCSOFI-3rdOrder-driftcorr_Icorr' mapName(1:end-7) '.tif' ]);

    toc
    %%
    %     clear output data_deconv
    fprintf('XC-SOFI applied to deconvolved dataset...')
    tic
    fprintf('Deconvolving...\n')
    data_deconv=deconvlucy(rescale(single(mean(data_rs2,4))),PSF,10);

    fprintf('Intensity correction...\n');
    mean_data_deconv=mean(data_deconv,[1 2]);
    data_deconv2=single(data_deconv).*(mean(single(data_deconv),'all')./mean_data_deconv);
    output_deconv.AC2=deconvlucy(rescale(output.AC2),PSF2,10);
    output_deconv.AC3=deconvlucy(rescale(output.AC3),PSF3,10);
    output_deconv.XC2=deconvlucy(rescale(output.XC2),PSF2,10);
    output_deconv.XC3=deconvlucy(rescale(output.XC3),PSF3,10);
    %     for i=1:st
    %
    %         data_deconv(:,:,:,i)=deconvlucy(rescale(single(data_rs2(:,:,:,i))),PSF,10);
    %         fprintf('Frame %d completed\n',i);
    %
    %     end

    %%
    %Intensity correction
    % fprintf('Intensity correction...\n');
    % mean_data_deconv=mean(data_deconv,[1 2]);
    % %data_deconv=uint16(rescale(data_deconv.*mean(data_deconv,'all')./mean_data_deconv)*60000);
    % data_deconv=uint16(data_deconv*60000);
    %     output_deconv=XC3DSOFI(data_deconv,'quick');
    %%
    saveastiff(uint16(data_deconv2/max(data_deconv2,'','all')*60000),[path_name,'\v4-' num2str(colorseq) '\deconv_' mapName(1:end-7) '.tif']);

    saveastiff(uint16(output_deconv.AC2/max(output_deconv.AC2,[],'all')*60000),[path_name,'\v4-' num2str(colorseq) '\3DACSOFI-2ndOrder-driftcorr-deconv_' mapName(1:end-7) '.tif']);
    saveastiff(uint16(output_deconv.AC2.^0.5/max(output_deconv.AC2,[],'all')^0.5*60000),[path_name,'\v4-' num2str(colorseq) '\3DACSOFI-2ndOrder-driftcorr-deconv_Icorr' mapName(1:end-7) '.tif']);
    saveastiff(uint16(output_deconv.AC3/max(output_deconv.AC3,[],'all')*60000),[path_name,'\v4-' num2str(colorseq) '\3DACSOFI-3rdOrder-driftcorr-deconv_' mapName(1:end-7) '.tif']);
    saveastiff(uint16(output_deconv.AC3.^0.33/max(output_deconv.AC3,[],'all')^0.33*60000),[path_name,'\v4-' num2str(colorseq) '\3DACSOFI-3rdOrder-driftcorr-deconv_Icorr' mapName(1:end-7) '.tif' ]);


    saveastiff(uint16(output_deconv.XC2/max(output_deconv.XC2,[],'all')*60000),[path_name,'\v4-' num2str(colorseq) '\3DXCSOFI-2ndOrder-driftcorr-deconv_' mapName(1:end-7) '.tif']);
    saveastiff(uint16(output_deconv.XC2.^0.5/max(output_deconv.XC2,[],'all')^0.5*60000),[path_name,'\v4-' num2str(colorseq) '\3DXCSOFI-2ndOrder-driftcorr-deconv_Icorr' mapName(1:end-7) '.tif']);
    saveastiff(uint16(output_deconv.XC3/max(output_deconv.XC3,[],'all')*60000),[path_name,'\v4-' num2str(colorseq) '\3DXCSOFI-3rdOrder-driftcorr-deconv_' mapName(1:end-7) '.tif']);
    saveastiff(uint16(output_deconv.XC3.^0.33/max(output_deconv.XC3,[],'all')^0.33*60000),[path_name,'\v4-' num2str(colorseq) '\3DXCSOFI-3rdOrder-driftcorr-deconv_Icorr' mapName(1:end-7) '.tif' ]);
    toc
    %%



end
end