% cryoSOFI_3D(d,'quick')
%
%   INPUT:
%   d           raw data stack
%   
%   'quick'     Uses only one set of taus [tau1, tau2, tau3, tau4].
%               Without 'quick' a permutation of all possibilities is used
%               and averaged.
%
%   EXAMPLE FOR USAGE: X = cryoSOFI_3D(d,'quick');
%       --> Data will be corrected for drift based on whole field of view
%           before calculating SOFI images in the 'quick' mode.
%
%   OUTPUT:
%   
%   XC: cross-correlation
%   

% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Edited by Brendan Gallagher 2020. Adapted from https://github.com/rainerkaufmann/cryoSOFI
%
% Removed autocorrelation and higher order (>2) cumulants
%
% Repurposed (currently repurposing) for use with 3D image stacks
%
% Essentially added equivalent correlations in Z to those in XY. Not sure
% if those are enough, may have to add more
%
% Currently only have 2nd-order cross-correlations but will add 3rd-order
%
% v1 - works, but some patterning seen in generated z slices
%
% v2 - attempting to correct that by changing XC2Diagonal1_3D and
% XC2Diagonal2_3D only. Vast improvement. Still slight patterning.
%
% v3 - attempting to correct with improvements to  XC2Vertical_3D and
% XC2Horizontal_3D.
%
%
%
%
%
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ output ] = ACXC3DSOFI( varargin )
d = varargin{1};

if numel(size(d)) ~= 4 
    
   msgbox('[ERROR] data must have four dimensions (XYZT)');
            return;  
 
end
if nargin >1
 if any( strcmpi( varargin, 'quick'))
        quick = 1;
 else
     quick = 0;
 end
end

%d = single(d);
delta = zeros(size(d));
delta = d-min(d,[],'all');
% delta = d-0.9*mean(d,'all');
% delta(:,:,:,delt) = bsxfun(@minus, d, mean(d,4)); 

tau1 = 2;
tau2 = 3;
tau3 = 4;
tau4 = 5;



    
  if any(strcmpi(varargin,'XC2'))
      
      mXC3 = 0;
      [ XC2 ] = XC_cryoSOFI(delta, tau1, tau2, tau3, tau4, quick, mXC3);
      
      output = XC2;
      
  else
    
    mXC3 = 1;
    [ XC2, XC3 ] = XC_cryoSOFI(delta, tau1, tau2, tau3, tau4, quick, mXC3);
    [ AC2, AC3 ] = AC_cryoSOFI(delta, tau1, tau2, tau3, tau4, quick);
    output = struct('AC2', AC2, 'AC3', AC3, 'XC2', XC2, 'XC3', XC3);

      
  end

end

function [ AC2, AC3 ] = AC_cryoSOFI ( delta, tau1, tau2, tau3, tau4, quick)
delta = double(delta);

xpix = size(delta,1);
ypix = size(delta,2);
nimages = size(delta,4);
nslices = size(delta,3);


if quick == 1
    tau = [tau1, tau2, tau3, tau4];
else
    tau = perms( [tau1, tau2, tau3, tau4] );
end
tauMax = max( [tau1, tau2, tau3, tau4] );
i = 1:xpix;
j = 1:ypix;
w = 1:nslices;

t = 1:( nimages-tauMax );

fprintf('Calculating auto-correlation SOFI images...');



%%%%%%%%%%% Auto-correlations
AC2 = zeros(xpix, ypix, nslices);
AC3 = zeros(xpix, ypix, nslices);

for k = 1:size(tau,1)
    AC2 = AC2 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j,w,t+tau(k,2))),4)/size(tau,1);
    AC3 = AC3 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j,w,t+tau(k,2)).*delta(i,j,w,t+tau(k,3))),4)/size(tau,1);

end
AC2 = imresize3(AC2,2);
AC3 = imresize3(AC3,3);
fprintf('Finished. \n');
end


function [ XC2, XC3 ] = XC_cryoSOFI ( delta, tau1, tau2, tau3, tau4, quick, mXC3)
delta = double(delta);
xpix = size(delta,1);
ypix = size(delta,2);
nimages = size(delta,4);
nslices = size(delta,3);

if quick == 1
    tau = [tau1, tau2, tau3, tau4];
else
    tau = perms( [tau1, tau2, tau3, tau4] );
end
tauMax = max( [tau1, tau2, tau3, tau4] );
i = 2:xpix-1;
j = 2:ypix-1;
w = 2:nslices-1;
t = 1:( nimages-tauMax );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%
%%%%%%%%%%% Calculate cross-correlation SOFI images
%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%% 2nd-order cross-correlation
fprintf('Calculating 2nd-order cross-correlation SOFI image...\n');

XC2_Central = zeros(xpix-2, ypix-2, nslices-2);
XC2_XX = zeros(xpix-2, ypix-2, nslices-2);
XC2_YY = zeros(xpix-2, ypix-2, nslices-2);
XC2_ZZ = zeros(xpix-2, ypix-2, nslices-2);
XC2_XY1 = zeros(xpix-2, ypix-2, nslices-2);
XC2_XY2 = zeros(xpix-2, ypix-2, nslices-2);
XC2_XZ1 = zeros(xpix-2, ypix-2, nslices-2);
XC2_XZ2 = zeros(xpix-2, ypix-2, nslices-2);
XC2_YZ1 = zeros(xpix-2, ypix-2, nslices-2);
XC2_YZ2 = zeros(xpix-2, ypix-2, nslices-2);
XC2_XYZ1 = zeros(xpix-2, ypix-2, nslices-2);
XC2_XYZ2 = zeros(xpix-2, ypix-2, nslices-2);
XC2_XYZ3 = zeros(xpix-2, ypix-2, nslices-2);
XC2_XYZ4 = zeros(xpix-2, ypix-2, nslices-2);


for k = 1:size(tau,1)
    XC2_Central = XC2_Central + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j,w,t+tau(k,2))),4)/size(tau,1);
    XC2_XX = XC2_XX + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j+1,w,t+tau(k,2))),4)/size(tau,1);
    XC2_YY = XC2_YY + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i+1,j,w,t+tau(k,2))),4)/size(tau,1);
    XC2_ZZ = XC2_ZZ + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j,w+1,t+tau(k,2))),4)/size(tau,1);
    XC2_XY1 = XC2_XY1 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i+1,j+1,w,t+tau(k,2))),4)/size(tau,1);
    XC2_XY2 = XC2_XY2 + mean(abs(delta(i+1,j,w,t+tau(k,1)).*delta(i,j+1,w,t+tau(k,2))),4)/size(tau,1);
    XC2_XZ1 = XC2_XZ1 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j+1,w+1,t+tau(k,2))),4)/size(tau,1);
    XC2_XZ2 = XC2_XZ2 + mean(abs(delta(i,j+1,w,t+tau(k,1)).*delta(i,j,w+1,t+tau(k,2))),4)/size(tau,1);
    XC2_YZ1 = XC2_YZ1 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i+1,j,w+1,t+tau(k,2))),4)/size(tau,1);
    XC2_YZ2 = XC2_YZ2 + mean(abs(delta(i+1,j,w,t+tau(k,1)).*delta(i,j,w+1,t+tau(k,2))),4)/size(tau,1);
    XC2_XYZ1 = XC2_XYZ1 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i+1,j+1,w+1,t+tau(k,2))),4)/size(tau,1);
    XC2_XYZ2 = XC2_XYZ2 + mean(abs(delta(i,j+1,w,t+tau(k,1)).*delta(i+1,j,w+1,t+tau(k,2))),4)/size(tau,1);
    XC2_XYZ3 = XC2_XYZ3 + mean(abs(delta(i+1,j,w,t+tau(k,1)).*delta(i,j+1,w+1,t+tau(k,2))),4)/size(tau,1);
    XC2_XYZ4 = XC2_XYZ4 + mean(abs(delta(i,j,w+1,t+tau(k,1)).*delta(i+1,j+1,w,t+tau(k,2))),4)/size(tau,1);
    
   
     
end



XC2_XY = (XC2_XY1+XC2_XY2)/2;
XC2_XZ = (XC2_XZ1+XC2_XZ2)/2;
XC2_YZ = (XC2_YZ1+XC2_YZ2)/2;
XC2_XYZ = (XC2_XYZ1+XC2_XYZ2+XC2_XYZ3+XC2_XYZ4)/4;

XC2xpixOUT = 2*(xpix-2)-1;
XC2ypixOUT = 2*(ypix-2)-1;
XC2zpixOUT = 2*(nslices-2)-1;
XC2 = zeros(XC2xpixOUT, XC2ypixOUT, XC2zpixOUT);
fprintf('Reconstructing Image...\n');


XC2(1:2:end,1:2:end,1:2:end) = XC2_Central(1:end,1:end,1:end);
XC2(1:2:end,2:2:end,1:2:end) = XC2_XX(1:end,1:end-1,1:end);
XC2(2:2:end,1:2:end,1:2:end) = XC2_YY(1:end-1,1:end,1:end);
XC2(2:2:end,2:2:end,1:2:end) = XC2_XY(1:end-1,1:end-1,1:end);
XC2(1:2:end,1:2:end,2:2:end) = XC2_ZZ(1:end,1:end,1:end-1);
XC2(1:2:end,2:2:end,2:2:end) = XC2_XZ(1:end,1:end-1,1:end-1);
XC2(2:2:end,1:2:end,2:2:end) = XC2_YZ(1:end-1,1:end,1:end-1);
XC2(2:2:end,2:2:end,2:2:end) = XC2_XYZ(1:end-1,1:end-1,1:end-1);

fprintf('Finished.\n\n');

%%%%%%%%%%% 3rd-order cross-correlation

if mXC3 == 1
fprintf('Calculating 3rd-order cross-correlation SOFI image...\n');

XC3_000 = zeros(xpix-2, ypix-2,nslices-2);
XC3_100 = zeros(xpix-2, ypix-2,nslices-2);
XC3_200 = zeros(xpix-2, ypix-2,nslices-2);
XC3_001 = zeros(xpix-2, ypix-2,nslices-2);
XC3_101 = zeros(xpix-2, ypix-2,nslices-2);
XC3_201 = zeros(xpix-2, ypix-2,nslices-2);
XC3_002 = zeros(xpix-2, ypix-2,nslices-2);
XC3_102 = zeros(xpix-2, ypix-2,nslices-2);
XC3_202 = zeros(xpix-2, ypix-2,nslices-2);
XC3_010 = zeros(xpix-2, ypix-2,nslices-2);
XC3_110 = zeros(xpix-2, ypix-2,nslices-2);
XC3_210 = zeros(xpix-2, ypix-2,nslices-2);
XC3_011 = zeros(xpix-2, ypix-2,nslices-2);
XC3_111 = zeros(xpix-2, ypix-2,nslices-2);
XC3_211 = zeros(xpix-2, ypix-2,nslices-2);
XC3_012 = zeros(xpix-2, ypix-2,nslices-2);
XC3_112 = zeros(xpix-2, ypix-2,nslices-2);
XC3_212 = zeros(xpix-2, ypix-2,nslices-2);
XC3_020 = zeros(xpix-2, ypix-2,nslices-2);
XC3_120 = zeros(xpix-2, ypix-2,nslices-2);
XC3_220 = zeros(xpix-2, ypix-2,nslices-2);
XC3_021 = zeros(xpix-2, ypix-2,nslices-2);
XC3_121 = zeros(xpix-2, ypix-2,nslices-2);
XC3_221 = zeros(xpix-2, ypix-2,nslices-2);
XC3_022 = zeros(xpix-2, ypix-2,nslices-2);
XC3_122 = zeros(xpix-2, ypix-2,nslices-2);
XC3_222 = zeros(xpix-2, ypix-2,nslices-2);




for k = 1:size(tau,1)
    XC3_000 = XC3_000 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j,w,t+tau(k,2)).*delta(i,j,w,t+tau(k,3))),4)/size(tau,1); %AAA
    XC3_100 = XC3_100 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j,w,t+tau(k,2)).*delta(i,j+1,w,t+tau(k,3))),4)/size(tau,1); %AAB
    XC3_200 = XC3_200 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j+1,w,t+tau(k,2)).*delta(i,j+1,w,t+tau(k,3))),4)/size(tau,1); %ABB
    XC3_001 = XC3_001 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j,w,t+tau(k,2)).*delta(i,j,w+1,t+tau(k,3))),4)/size(tau,1); %AAE
    XC3_101 = XC3_101 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j+1,w,t+tau(k,2)).*delta(i,j,w+1,t+tau(k,3))),4)/size(tau,1)/2 ...
                      + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j,w,t+tau(k,2)).*delta(i,j+1,w+1,t+tau(k,3))),4)/size(tau,1)/2; %ABE&AAF
    XC3_201 = XC3_201 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j+1,w,t+tau(k,2)).*delta(i,j+1,w+1,t+tau(k,3))),4)/size(tau,1)/2 ...
                      + mean(abs(delta(i,j+1,w,t+tau(k,1)).*delta(i,j+1,w,t+tau(k,2)).*delta(i,j,w+1,t+tau(k,3))),4)/size(tau,1)/2; %ABF&BBE
    XC3_002 = XC3_002 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j,w+1,t+tau(k,2)).*delta(i,j,w+1,t+tau(k,3))),4)/size(tau,1); %AEE
    XC3_102 = XC3_102 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j,w+1,t+tau(k,2)).*delta(i,j+1,w+1,t+tau(k,3))),4)/size(tau,1)/2 ...
                      + mean(abs(delta(i,j+1,w,t+tau(k,1)).*delta(i,j,w+1,t+tau(k,2)).*delta(i,j,w+1,t+tau(k,3))),4)/size(tau,1)/2; %AEF&BEE
    XC3_202 = XC3_202 + mean(abs(delta(i,j+1,w,t+tau(k,1)).*delta(i,j,w+1,t+tau(k,2)).*delta(i,j+1,w+1,t+tau(k,3))),4)/size(tau,1)/2 ...
                      + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j+1,w+1,t+tau(k,2)).*delta(i,j+1,w+1,t+tau(k,3))),4)/size(tau,1)/2; %BEF&AFF
    XC3_010 = XC3_010 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j,w,t+tau(k,2)).*delta(i+1,j,w,t+tau(k,3))),4)/size(tau,1); %AAC
    XC3_110 = XC3_110 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j+1,w,t+tau(k,2)).*delta(i+1,j,w,t+tau(k,3))),4)/size(tau,1)/2 ...
                      + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j,w,t+tau(k,2)).*delta(i+1,j+1,w,t+tau(k,3))),4)/size(tau,1)/2; %ABC&AAD
    XC3_210 = XC3_210 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j+1,w,t+tau(k,2)).*delta(i+1,j+1,w,t+tau(k,3))),4)/size(tau,1)/2 ...
                      + mean(abs(delta(i,j+1,w,t+tau(k,1)).*delta(i,j+1,w,t+tau(k,2)).*delta(i+1,j,w,t+tau(k,3))),4)/size(tau,1)/2; %ABD&BBC
    XC3_011 = XC3_011 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i+1,j,w,t+tau(k,2)).*delta(i,j,w+1,t+tau(k,3))),4)/size(tau,1)/2 ...
                      + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j,w,t+tau(k,2)).*delta(i+1,j,w+1,t+tau(k,3))),4)/size(tau,1)/2; %ACE&AAG
    XC3_111 = XC3_111 + mean(abs(delta(i,j+1,w,t+tau(k,1)).*delta(i+1,j,w,t+tau(k,2)).*delta(i,j,w+1,t+tau(k,3))),4)/size(tau,1)/3 ...
                      + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i+1,j+1,w,t+tau(k,2)).*delta(i,j,w+1,t+tau(k,3))),4)/size(tau,1)/3 ...
                      + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j,w,t+tau(k,2)).*delta(i+1,j+1,w+1,t+tau(k,3))),4)/size(tau,1)/3; %BCE&ADE&AAH
    XC3_211 = XC3_211 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i+1,j+1,w,t+tau(k,2)).*delta(i,j+1,w+1,t+tau(k,3))),4)/size(tau,1)/3 ...
                      + mean(abs(delta(i,j+1,w,t+tau(k,1)).*delta(i+1,j,w,t+tau(k,2)).*delta(i,j+1,w+1,t+tau(k,3))),4)/size(tau,1)/3 ...
                      + mean(abs(delta(i,j+1,w,t+tau(k,1)).*delta(i,j+1,w,t+tau(k,2)).*delta(i+1,j,w+1,t+tau(k,3))),4)/size(tau,1)/3; %ADF&BCF&BBG
    XC3_012 = XC3_012 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j,w+1,t+tau(k,2)).*delta(i+1,j,w+1,t+tau(k,3))),4)/size(tau,1)/2 ...
                      + mean(abs(delta(i+1,j,w,t+tau(k,1)).*delta(i,j,w+1,t+tau(k,2)).*delta(i,j,w+1,t+tau(k,3))),4)/size(tau,1)/2; %AEG&CEE
    XC3_112 = XC3_112 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j+1,w+1,t+tau(k,2)).*delta(i+1,j,w+1,t+tau(k,3))),4)/size(tau,1)/3 ...
                      + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i,j,w+1,t+tau(k,2)).*delta(i+1,j+1,w+1,t+tau(k,3))),4)/size(tau,1)/3 ...
                      + mean(abs(delta(i+1,j+1,w,t+tau(k,1)).*delta(i,j,w+1,t+tau(k,2)).*delta(i,j,w+1,t+tau(k,3))),4)/size(tau,1)/3; %AFG&AEH&DEE
    XC3_212 = XC3_212 + mean(abs(delta(i,j+1,w,t+tau(k,1)).*delta(i,j,w+1,t+tau(k,2)).*delta(i+1,j+1,w+1,t+tau(k,3))),4)/size(tau,1)/3 ...
                      + mean(abs(delta(i,j+1,w,t+tau(k,1)).*delta(i,j+1,w+1,t+tau(k,2)).*delta(i+1,j,w+1,t+tau(k,3))),4)/size(tau,1)/3 ...
                      + mean(abs(delta(i+1,j,w,t+tau(k,1)).*delta(i,j+1,w+1,t+tau(k,2)).*delta(i,j+1,w+1,t+tau(k,3))),4)/size(tau,1)/3; %BEH&BFG&CFF
    XC3_020 = XC3_020 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i+1,j,w,t+tau(k,2)).*delta(i+1,j,w,t+tau(k,3))),4)/size(tau,1); %ACC
    XC3_120 = XC3_120 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i+1,j,w,t+tau(k,2)).*delta(i+1,j+1,w,t+tau(k,3))),4)/size(tau,1)/2 ...
                      + mean(abs(delta(i,j+1,w,t+tau(k,1)).*delta(i+1,j,w,t+tau(k,2)).*delta(i+1,j,w,t+tau(k,3))),4)/size(tau,1)/2; %ACD&BCC
    XC3_220 = XC3_220 + mean(abs(delta(i,j+1,w,t+tau(k,1)).*delta(i+1,j,w,t+tau(k,2)).*delta(i+1,j+1,w,t+tau(k,3))),4)/size(tau,1)/2 ...
                      + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i+1,j+1,w,t+tau(k,2)).*delta(i+1,j+1,w,t+tau(k,3))),4)/size(tau,1)/2; %BCD&ADD
    XC3_021 = XC3_021 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i+1,j,w,t+tau(k,2)).*delta(i+1,j,w+1,t+tau(k,3))),4)/size(tau,1)/2 ...
                      + mean(abs(delta(i+1,j,w,t+tau(k,1)).*delta(i+1,j,w,t+tau(k,2)).*delta(i,j,w+1,t+tau(k,3))),4)/size(tau,1)/2; %ACG&CCE
    XC3_121 = XC3_121 + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i+1,j+1,w,t+tau(k,2)).*delta(i+1,j,w+1,t+tau(k,3))),4)/size(tau,1)/3 ...
                      + mean(abs(delta(i,j+1,w,t+tau(k,1)).*delta(i+1,j,w,t+tau(k,2)).*delta(i+1,j,w+1,t+tau(k,3))),4)/size(tau,1)/3 ...
                      + mean(abs(delta(i+1,j,w,t+tau(k,1)).*delta(i+1,j,w,t+tau(k,2)).*delta(i,j+1,w+1,t+tau(k,3))),4)/size(tau,1)/3; %ADG&BCG&CCF
    XC3_221 = XC3_221 + mean(abs(delta(i,j+1,w,t+tau(k,1)).*delta(i+1,j,w,t+tau(k,2)).*delta(i+1,j+1,w+1,t+tau(k,3))),4)/size(tau,1)/3 ...
                      + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i+1,j+1,w,t+tau(k,2)).*delta(i+1,j+1,w+1,t+tau(k,3))),4)/size(tau,1)/3 ...
                      + mean(abs(delta(i+1,j+1,w,t+tau(k,1)).*delta(i+1,j+1,w,t+tau(k,2)).*delta(i,j,w+1,t+tau(k,3))),4)/size(tau,1)/3; %BCH&ADH&DDE
    XC3_022 = XC3_022 + mean(abs(delta(i+1,j,w,t+tau(k,1)).*delta(i,j,w+1,t+tau(k,2)).*delta(i+1,j,w+1,t+tau(k,3))),4)/size(tau,1)/2 ...
                      + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i+1,j,w+1,t+tau(k,2)).*delta(i+1,j,w+1,t+tau(k,3))),4)/size(tau,1)/2; %CEG&AGG
    XC3_122 = XC3_122 + mean(abs(delta(i+1,j,w,t+tau(k,1)).*delta(i,j,w+1,t+tau(k,2)).*delta(i+1,j+1,w+1,t+tau(k,3))),4)/size(tau,1)/3 ...
                      + mean(abs(delta(i+1,j,w,t+tau(k,1)).*delta(i,j+1,w+1,t+tau(k,2)).*delta(i+1,j,w+1,t+tau(k,3))),4)/size(tau,1)/3 ...
                      + mean(abs(delta(i,j+1,w,t+tau(k,1)).*delta(i+1,j,w+1,t+tau(k,2)).*delta(i+1,j,w+1,t+tau(k,3))),4)/size(tau,1)/3; %CEH&CFG&BGG
    XC3_222 = XC3_222 + mean(abs(delta(i+1,j+1,w,t+tau(k,1)).*delta(i,j+1,w+1,t+tau(k,2)).*delta(i+1,j,w+1,t+tau(k,3))),4)/size(tau,1)/3 ...
                      + mean(abs(delta(i+1,j+1,w,t+tau(k,1)).*delta(i,j,w+1,t+tau(k,2)).*delta(i+1,j+1,w+1,t+tau(k,3))),4)/size(tau,1)/3 ...
                      + mean(abs(delta(i,j,w,t+tau(k,1)).*delta(i+1,j+1,w+1,t+tau(k,2)).*delta(i+1,j+1,w+1,t+tau(k,3))),4)/size(tau,1)/3; %DFG&DEH&AHH
    
end


fprintf('Reconstructing Image...\n');
XC3xpixOUT = 3*(xpix-2)-2;
XC3ypixOUT = 3*(ypix-2)-2;
XC3zpixOUT = 3*(nslices-2)-2;
XC3 = zeros(XC3xpixOUT, XC3ypixOUT, XC3zpixOUT);


XC3(1:3:end,1:3:end,1:3:end) = XC3_000(1:end,1:end,1:end); %1
XC3(1:3:end,2:3:end,1:3:end) = XC3_100(1:end,1:end-1,1:end); %2
XC3(1:3:end,3:3:end,1:3:end) = XC3_200(1:end,1:end-1,1:end); %3
XC3(2:3:end,1:3:end,1:3:end) = XC3_010(1:end-1,1:end,1:end); %4
XC3(3:3:end,1:3:end,1:3:end) = XC3_020(1:end-1,1:end,1:end); %7
XC3(2:3:end,2:3:end,1:3:end) = XC3_110(1:end-1,1:end-1,1:end); %5
XC3(3:3:end,3:3:end,1:3:end) = XC3_220(1:end-1,1:end-1,1:end); %9
XC3(2:3:end,3:3:end,1:3:end) = XC3_210(1:end-1,1:end-1,1:end); %6
XC3(3:3:end,2:3:end,1:3:end) = XC3_120(1:end-1,1:end-1,1:end); %8


XC3(1:3:end,1:3:end,2:3:end) = XC3_001(1:end,1:end,1:end-1); %10
XC3(1:3:end,2:3:end,2:3:end) = XC3_101(1:end,1:end-1,1:end-1); %11
XC3(1:3:end,3:3:end,2:3:end) = XC3_201(1:end,1:end-1,1:end-1); %12
XC3(2:3:end,1:3:end,2:3:end) = XC3_011(1:end-1,1:end,1:end-1); %13
XC3(3:3:end,1:3:end,2:3:end) = XC3_021(1:end-1,1:end,1:end-1); %16
XC3(2:3:end,2:3:end,2:3:end) = XC3_111(1:end-1,1:end-1,1:end-1); %14
XC3(3:3:end,3:3:end,2:3:end) = XC3_221(1:end-1,1:end-1,1:end-1); %18
XC3(2:3:end,3:3:end,2:3:end) = XC3_211(1:end-1,1:end-1,1:end-1); %15
XC3(3:3:end,2:3:end,2:3:end) = XC3_121(1:end-1,1:end-1,1:end-1); %17


XC3(1:3:end,1:3:end,3:3:end) = XC3_002(1:end,1:end,1:end-1); %19
XC3(1:3:end,2:3:end,3:3:end) = XC3_102(1:end,1:end-1,1:end-1); %20
XC3(1:3:end,3:3:end,3:3:end) = XC3_202(1:end,1:end-1,1:end-1); %21
XC3(2:3:end,1:3:end,3:3:end) = XC3_012(1:end-1,1:end,1:end-1); %22
XC3(3:3:end,1:3:end,3:3:end) = XC3_022(1:end-1,1:end,1:end-1); %25
XC3(2:3:end,2:3:end,3:3:end) = XC3_112(1:end-1,1:end-1,1:end-1); %23
XC3(3:3:end,3:3:end,3:3:end) = XC3_222(1:end-1,1:end-1,1:end-1); %27
XC3(2:3:end,3:3:end,3:3:end) = XC3_212(1:end-1,1:end-1,1:end-1); %24
XC3(3:3:end,2:3:end,3:3:end) = XC3_122(1:end-1,1:end-1,1:end-1); %26


fprintf('Finished.\n\n');
clear XC3Central XC3Horizontal1 XC3Horizontal2 XC3Vertical1 XC3Vertical2 XC3Diagonal1...
    XC3Diagonal2 XC3Diagonal3 XC3Diagonal4 XC3Central_3D1 XC3Central_3D2 XC3Horizontal_3D1...
    XC3Horizontal_3D2 XC3Horizontal_3D3 XC3Horizontal_3D4 XC3Vertical_3D1 XC3Vertical_3D2...
    XC3Vertical_3D3 XC3Vertical_3D4 XC3Diagonal_3D1 XC3Diagonal_3D2 XC3Diagonal_3D3...
    XC3Diagonal_3D4 XC3Diagonal_3D5 XC3Diagonal_3D6 XC3Diagonal_3D7 XC3Diagonal_3D8;
end
end


