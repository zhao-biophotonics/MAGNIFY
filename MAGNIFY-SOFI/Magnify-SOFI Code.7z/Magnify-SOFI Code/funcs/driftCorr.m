function [correctedIm, shiftX, shiftY]=driftCorr(im1,im2)
[sy,sx]=size(im1);
% Using fft cross correlations to detect the moving distance[1]
fftim1=fft2(im1);
fftim2=fft2(im2);
cc=fftshift(ifft2(fftim1.*conj(fftim2)));
[shiftY,shiftX]=find(cc==max(cc(:)));
shiftY=shiftY-fix(sy/2)-1;
shiftX=shiftX-fix(sx/2)-1;
correctedIm=circshift(im2,[shiftY,shiftX]);
end